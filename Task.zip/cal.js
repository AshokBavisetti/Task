import React,{useState} from 'react'
import './k.css'
export default function Cal() {
const[result,setResult]=useState("")
const changeHandler=(event)=>{
    setResult(result.concat(event.target.value))
}
const changeReset=(event)=>{
    setResult("")
}
const changeClear=()=>{
    setResult(result.slice(0,result.length-1))
}
const output=()=>{
    //eslint-disable-next-line
    setResult(eval(result.toString()))
}
  return (
    <div class="cal">
      <input type="text" id="answer" value={result} />
      <input type="button" className="btn" value="9" onClick={changeHandler} />
      <input type="button" className="btn" value="8" onClick={changeHandler} />
      <input type="button" className="btn" value="7" onClick={changeHandler} />
      <input type="button" className="btn" value="6" onClick={changeHandler} />
      <input type="button" className="btn" value="5" onClick={changeHandler} />
      <input type="button" className="btn" value="4" onClick={changeHandler} />
      <input type="button" className="btn" value="3" onClick={changeHandler} />
      <input type="button" className="btn" value="2" onClick={changeHandler} />
      <input type="button" className="btn" value="1" onClick={changeHandler} />
      <input type="button" className="btn" value="0" onClick={changeHandler} />
      <input type="button" className="btn" value="." onClick={changeHandler} />
      <input type="button" className="btn" value="+" onClick={changeHandler} />
      <input type="button" className="btn" value="-" onClick={changeHandler} />
      <input type="button" className="btn" value="*" onClick={changeHandler} />
      <input type="button" className="btn" value="/" onClick={changeHandler} />
      <input type="button" className="btn" value="%" onClick={changeHandler} />
      <input type="button" className="btn btn1" value="c" onClick={changeClear} />
      <input type="button" className="btn btn1" value="clear" onClick={changeReset} />
       <input type="button" className="btn btn1" value="=" onClick={output} />
    </div>
  );
}
